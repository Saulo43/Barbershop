const express = require('express');
const app = express();
const cors = require('cors');
const horarios = require('./db.json');

app.use(cors());
app.use(express.static('public'));

app.get('/horarios', (req, res) => {
  res.json(horarios);
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log('Servidor rodando em http://localhost:' + PORT);
});