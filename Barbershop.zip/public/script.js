fetch('/horarios')
  .then(res => res.json())
  .then(data => {
    const container = document.getElementById('horarios');
    data.forEach(horario => {
      const btn = document.createElement('button');
      btn.innerText = horario;
      btn.onclick = () => alert('Horário agendado: ' + horario);
      container.appendChild(btn);
    });
  });